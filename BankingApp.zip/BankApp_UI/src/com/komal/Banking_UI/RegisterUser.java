package com.komal.Banking_UI;
import java.sql.*;


import com.komal.connect.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class RegisterUser
 */
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try
		{
			String cname=request.getParameter("cname");
			String ccontact=request.getParameter("ccontact");
			String cemail=request.getParameter("cemail");
			String cpassword=request.getParameter("cpassword");
			
			Connection con=ConnectDB.dbCon();
			PreparedStatement ps2=con.prepareStatement("insert into chef values (?,?,?,?)");
		
			ps2.setString(1, cname);
			ps2.setInt(2, Integer.parseInt(ccontact));
			ps2.setString(3, cemail);
			ps2.setString(4, cpassword);
			
			int i=ps2.executeUpdate();
			if(i>0)
			{
				response.sendRedirect("index.html");
			
		}
		else
		{
			response.sendRedirect("error.html");
		}
	}
	catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}