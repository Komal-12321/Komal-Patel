package com.komal.Banking_UI;
import com.komal.connect.ConnectDB;

public class User {
	public static String uemail;

	public static String getUemail() {
		return uemail;
	}

	public static void setUemail(String uemail) {
		User.uemail = uemail;
	}
}