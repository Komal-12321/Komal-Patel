package com.komal.chef;

public class PojoUser {
	public static int uid;
	
	public static int getUid() {
		return uid;
	}

	public static void setUid(int uid) {
		PojoUser.uid = uid;
	}
	
public static int cid;
	
	public static int getCid() {
		return cid;
	}

	public static void setCid(int cid) {
		PojoUser.cid = cid;
	}
}