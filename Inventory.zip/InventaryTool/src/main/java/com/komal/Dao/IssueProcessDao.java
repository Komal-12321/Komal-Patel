package com.komal.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.komal.model.IssueProcess1;
import com.komal.model.Process;

@Component
public class IssueProcessDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public int addIssueProcess1 (IssueProcess1 issueProcess1) 
		{
		int i = (Integer) this.hibernateTemplate.save(issueProcess1);
		return i;
		}

	public  List<IssueProcess1> getAllProcesses() {
		List<IssueProcess1> processes = this.hibernateTemplate.loadAll(IssueProcess1.class);
		return processes;
	}

}
