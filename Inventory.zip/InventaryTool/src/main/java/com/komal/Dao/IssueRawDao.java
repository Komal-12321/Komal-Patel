package com.komal.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.komal.model.IssueProcess1;
import com.komal.model.IssueRaw1;

@Component
public class IssueRawDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public int addIssueRaw1 (IssueRaw1 issueRaw1) 
		{
		int i = (Integer) this.hibernateTemplate.save(issueRaw1);
		return i;
		}
	public  List<IssueRaw1> getAllRaws() {
		List<IssueRaw1> raws = this.hibernateTemplate.loadAll(IssueRaw1.class);
		return raws;
	}

}
