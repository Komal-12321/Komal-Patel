package com.komal.Dao;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.komal.model.Manager;

@Component
public class ManagerDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public int addManager (Manager manager) 
		{
		int i = (Integer) this.hibernateTemplate.save(manager);
		return i;
		}
	
	@Transactional
	 public void updateManager(Manager manager) {
		 this.hibernateTemplate.update(manager);
		 }

	public Manager getManager(String mEmail) {
			Manager manager = this.hibernateTemplate.get(Manager.class, mEmail);
			return manager;
	}

	
	}
		
