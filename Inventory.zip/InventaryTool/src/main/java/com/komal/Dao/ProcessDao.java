package com.komal.Dao;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.komal.model.Process;

@Component
public class ProcessDao {
		
		@Autowired
		private HibernateTemplate hibernateTemplate;
		
		@Transactional
		public int addProcess (Process process) 
			{
			int i = (Integer) this.hibernateTemplate.save(process);
			return i;
			}
		
		public List<Process> getAllProcesses() {
			List<Process> processes = this.hibernateTemplate.loadAll(Process.class);
			return processes;
			}
		
		public Process getProcess(int pId) {
			Process process = this.hibernateTemplate.get(Process.class, pId);
			return process;
			}

		@Transactional
		public void deleteProcess(int pId) {
			Process process = this.hibernateTemplate.get(Process.class, pId);
		this.hibernateTemplate.delete(process);
		}
	
		@Transactional
		 public void updateProcess(Process process) {
			 this.hibernateTemplate.update(process);
			 }
		
}
