package com.komal.Dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.komal.model.Raw;

@Component
public class RawDao {
		
		@Autowired
		private HibernateTemplate hibernateTemplate;
		
		@Transactional
		public int addRaw (Raw raw) 
			{
			int i = (Integer) this.hibernateTemplate.save(raw);
			return i;
			}
		
		public List<Raw> getAllRaws() {
			List<Raw> raws = this.hibernateTemplate.loadAll(Raw.class);
			return raws;
			}
		
		public Raw getRaw(int rId) {
			Raw raw = this.hibernateTemplate.get(Raw.class, rId);
			return raw;
			}

		@Transactional
		public void deleteRaw(int rId) {
		Raw raw = this.hibernateTemplate.get(Raw.class, rId);
		this.hibernateTemplate.delete(raw);
		}
		
		@Transactional
		 public void updateRaw(Raw raw) {
			 this.hibernateTemplate.update(raw);
			 }
		
}
