package com.komal.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.komal.Dao.RawDao;
import com.komal.model.IssueRaw1;
import com.komal.model.Raw;

@Controller
 	public class Home
 	{
	@Autowired
	Raw raw;
	@Autowired
	RawDao rawDao;
			@RequestMapping("/addRaw")
			
			public String addRaw()
			{
				System.out.println("Add Raw Material..");
				return "addRawMaterial";
			}
			
			@RequestMapping(path="/addNewRaw",method=RequestMethod.POST)
			public String addNewRaw (@ModelAttribute Raw raw, HttpServletRequest request)
			{
				int i=rawDao.addRaw(raw);
				return "addRawMaterial";
			}
			
			
			@RequestMapping("/viewRaw")
			
			public String viewAccount(Model model)
			{
				List<Raw> raws=rawDao.getAllRaws();
				model.addAttribute("rawList",raws);
				return "viewRawMaterial";
			}
			
			@RequestMapping("/viewUnavailRaw")
			
			public String viewUnavail(Model model)
			{
				List<Raw> raws=rawDao.getAllRaws();
				model.addAttribute("rawList",raws);
				return "unavailableRaw";
			}
			
			
	
			@RequestMapping("/deleteRaw")
			
			public String delete()
			{
				System.out.println("Deposit Money..");
				return "deleteRawMaterial";
			}
			
			@RequestMapping(path="/deleteNewRaw",method=RequestMethod.POST)
			public String deleteRaw (HttpServletRequest request, Model model)
			{
				
        		int rId = Integer.parseInt((request.getParameter("rId")));
        		rawDao.deleteRaw(rId);
				return "deleteRawMaterial";
			}
			
			
			@RequestMapping("/updateRaw")
			
			public String update()
			{
				System.out.println("Update Raw Material");
				return "updateRawMaterial";
			}
			
			@RequestMapping(path="/updateNewRaw",method=RequestMethod.POST)
			public String updateRaw (HttpServletRequest request, Model model)
			{
				int rId=Integer.parseInt((request.getParameter("rId")));
				float add=Float.parseFloat(request.getParameter("add"));
				Raw raw = rawDao.getRaw(rId);
	 		    if (raw != null) 
	 		    {
	 		        float newAddition = raw.getrQuantity() + add;
	 		       raw.setrQuantity(newAddition);
	 		        rawDao.updateRaw(raw);
	 		        return "updateRawMaterial";
	 		    } 
	 		    else 
	 		    {
	 		       return "index";
	 		    }
			}
				
			
			@RequestMapping("/RawWelcome")
			
			public String RawWelcome()
			{
				System.out.println("Raw Material Main Page..");
				return "RawWelcome";
			}
			
			@RequestMapping("/ProcessedWelcome")
			
			public String ProcessedWelcome()
			{
				System.out.println("Processed Material Main Page..");
				return "ProcessedWelcome";
			}
			
			@RequestMapping("/Welcome")
			
			public String Welcome()
			{
				System.out.println("Main Page..");
				return "Welcome";
			}
			
			@RequestMapping(path="/delete", method=RequestMethod.GET)
			
			public String delete2(HttpServletRequest request)
			{
				int rId=Integer.parseInt(request.getParameter("rId"));
				rawDao.deleteRaw(rId);
				System.out.println("Delete...");
				return "redirect://viewRaw";
			}
			
	}

