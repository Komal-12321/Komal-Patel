	package com.komal.controller;
import java.util.List;



import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.komal.Dao.ProcessDao;
import com.komal.model.Process;

@Controller
 	public class HomeProcessed
 	{
	@Autowired
	Process process;
	@Autowired
	ProcessDao processDao;

			@RequestMapping("/addProcess")
			
			public String addProcess()
			{
				System.out.println("Add Processed Material..");
				return "addProcessedMaterial";
			}
			
			@RequestMapping(path="/addNewProcess",method=RequestMethod.POST)
			public String addNewProcesses (@ModelAttribute Process process, HttpServletRequest request)
			{
				int i=processDao.addProcess(process);
				return "addProcessedMaterial";
			}
			
			
			@RequestMapping("/viewProcess")
			
			public String viewAccount(Model model)
			{
				List<Process> processes=processDao.getAllProcesses();
				model.addAttribute("processList",processes);
				return "viewProcessedMaterial";
			}
			
			@RequestMapping("/viewUnavailProcess")
			
			public String viewUnavail(Model model)
			{
				List<Process> processes=processDao.getAllProcesses();
				model.addAttribute("processList",processes);
				return "unavailableProcessed";
			}
			
			@RequestMapping("/deleteProcess")
			
			public String delete()
			{
				System.out.println("Delete");
				return "deleteProcessedMaterial";
			}
			
			@RequestMapping(path="/deleteNewProcess",method=RequestMethod.POST)
			public String deleteRaw (HttpServletRequest request, Model model)
			{
				
        		int pId = Integer.parseInt((request.getParameter("pId")));
        		processDao.deleteProcess(pId);
				return "deleteProcessedMaterial";
			}
			
			
			@RequestMapping("/updateProcess")
			
			public String update()
			{
				System.out.println("Update Processed Material");
				return "updateProcessedMaterial";
			}
			
			@RequestMapping(path="/updateNewProcess",method=RequestMethod.POST)
			public String updateProcess (HttpServletRequest request, Model model)
			{
				int pId=Integer.parseInt((request.getParameter("pId")));
				float add=Float.parseFloat(request.getParameter("add"));
				Process process = processDao.getProcess(pId);
	 		    if (process != null) 
	 		    {
	 		        float newAddition = process.getpQuantity() + add;
	 		       process.setpQuantity(newAddition);
	 		      processDao.updateProcess(process);
	 		        return "updateProcessedMaterial";
	 		    } 
	 		    else 
	 		    {
	 		       return "index";
	 		    }
			}
			
			@RequestMapping(path="/delete1", method=RequestMethod.GET)
			public String delete2(HttpServletRequest request)
			{
				int pId=Integer.parseInt(request.getParameter("pId"));
				processDao.deleteProcess(pId);
				System.out.println("Delete...");
				return "redirect://viewProcess";
			}
	}

