package com.komal.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.komal.Dao.IssueProcessDao;
import com.komal.model.IssueProcess1;
import com.komal.model.Raw;

@Controller
public class IssueProcessed {
 	
	@Autowired
	private IssueProcess1 issueProcess1;
	@Autowired
	private IssueProcessDao issueProcessDao;

	
			@RequestMapping("/issueProcess")
			
			public String issue1()
			{
				System.out.println("IssueProcess");
				return "issueProcessMaterial";
			}
	
			@RequestMapping("/addIssueProcess")
			
			public String addIssueProcess1()
			{
				System.out.println("Issue Material..");
				return "issueProcessMaterial";
			}
			
			@RequestMapping(path="/addProcessedIssue",method=RequestMethod.POST)
			public String addNewIssues(@ModelAttribute IssueProcess1 issueProcess1, HttpServletRequest request)
			{
				int i=issueProcessDao.addIssueProcess1(issueProcess1);
				return "issueProcessMaterial";
			}
			
			@RequestMapping("/viewIssueProcessed")
			
			public String viewAccount(Model model)
			{
				List<IssueProcess1> processes=issueProcessDao.getAllProcesses();
				model.addAttribute("processList",processes);
				return "issueViewProcessed";
			}
			
			
}
