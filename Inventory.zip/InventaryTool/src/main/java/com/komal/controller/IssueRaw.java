package com.komal.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.komal.Dao.IssueRawDao;
import com.komal.model.IssueProcess1;
import com.komal.model.IssueRaw1;
import com.komal.model.Raw;
@Controller
public class IssueRaw {
 	
	@Autowired
	private IssueRaw1 issueRaw1;
	@Autowired
	private IssueRawDao issueRawDao;

	
			@RequestMapping("/issueRaw")
			
			public String issue()
			{
				System.out.println("IssueRaw");
				return "issueRawMaterial";
			}
	
			@RequestMapping("/addIssueRaw")
			
			public String addIssueRaw1()
			{
				System.out.println("Issue Material..");
				return "issueRawMaterial";
			}
			
			@RequestMapping(path="/addNewIssue",method=RequestMethod.POST)
			public String addNewIssues(@ModelAttribute IssueRaw1 issueRaw1, HttpServletRequest request)
			{
				int i=issueRawDao.addIssueRaw1(issueRaw1);
				return "issueRawMaterial";
			}
			
			@RequestMapping("/viewIssueRaw")
			
			public String viewAccount(Model model)
			{
				List<IssueRaw1> raws=issueRawDao.getAllRaws();
				model.addAttribute("rawList",raws);
				return "issueViewRaw";
			}
	
			
}
