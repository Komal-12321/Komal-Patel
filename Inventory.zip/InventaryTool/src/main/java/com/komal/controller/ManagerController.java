package com.komal.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.komal.Dao.ManagerDao;
import com.komal.model.Manager;

@Controller
 	public class ManagerController
 	{
	@Autowired
	Manager manager;
	@Autowired
	ManagerDao managerDao;
		@RequestMapping("/")
		
		public String index()
		{
			System.out.println("Index page..");
			return "index";
		}
		
		@RequestMapping(path="/loginAdmin", method=RequestMethod.POST)
		public String adminLogin(HttpServletRequest request, Model model) {
				String mEmail=request.getParameter("mEmail");
				String mPassword=request.getParameter("mPassword");
				manager=managerDao.getManager(mEmail);
				String mPassword1=manager.getmPassword();

				
		    if (manager!=null && mPassword.equals(mPassword1)) 
		    {
		        return "Welcome";
		    } else {
		        return "index"; 
		    }
		}
		
		@RequestMapping("/changepass")
		
		public String issue1()
		{
			System.out.println("Change");
			return "ChangePassword";
		}

		@RequestMapping(path="/changepasslogic",method=RequestMethod.POST)
		public String withMoney (HttpServletRequest request, Model model)
		{
			String mEmail=request.getParameter("mEmail");
			String nPassword=request.getParameter("nPassword");
			String pass=request.getParameter("pass");
 		    if (nPassword.equals(pass)) 
 		    {
 		       manager.setmPassword(nPassword);
 		        managerDao.updateManager(manager);
 		        return "ChangePassword";
 		    } 
 		    else 
 		    {
 		       return "index";
 		    }
		}
		
	}