package com.komal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class IssueProcess1 {

	@Id
	private int IpId;
	private int pId;
	private String IpName;
	private String IpIssuer;
	private float IpQuantity;
	private String IpDate;
	private String IpTime;
	public int getIpId() {
		return IpId;
	}
	public IssueProcess1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IssueProcess1(int ipId, int pId, String ipName, String ipIssuer, float ipQuantity, String ipDate,
			String ipTime) {
		super();
		IpId = ipId;
		this.pId = pId;
		IpName = ipName;
		IpIssuer = ipIssuer;
		IpQuantity = ipQuantity;
		IpDate = ipDate;
		IpTime = ipTime;
	}
	@Override
	public String toString() {
		return "IssueProcess1 [IpId=" + IpId + ", pId=" + pId + ", IpName=" + IpName + ", IpIssuer=" + IpIssuer
				+ ", IpQuantity=" + IpQuantity + ", IpDate=" + IpDate + ", IpTime=" + IpTime + "]";
	}
	public void setIpId(int ipId) {
		IpId = ipId;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getIpName() {
		return IpName;
	}
	public void setIpName(String ipName) {
		IpName = ipName;
	}
	public String getIpIssuer() {
		return IpIssuer;
	}
	public void setIpIssuer(String ipIssuer) {
		IpIssuer = ipIssuer;
	}
	public float getIpQuantity() {
		return IpQuantity;
	}
	public void setIpQuantity(float ipQuantity) {
		IpQuantity = ipQuantity;
	}
	public String getIpDate() {
		return IpDate;
	}
	public void setIpDate(String ipDate) {
		IpDate = ipDate;
	}
	public String getIpTime() {
		return IpTime;
	}
	public void setIpTime(String ipTime) {
		IpTime = ipTime;
	}

}