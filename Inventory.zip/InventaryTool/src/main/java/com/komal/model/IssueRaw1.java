package com.komal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class IssueRaw1 {

	@Id
	private int IrId;
	private int rId;
	private String IrName;
	private String IrIssuer;
	private float IrQuantity;
	private String IrDate;
	private String IrTime;
	
	public IssueRaw1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IssueRaw1(int irId, int rId, String irName, String irIssuer, float irQuantity, String irDate, String irTime) {
		super();
		IrId = irId;
		this.rId = rId;
		IrName = irName;
		IrIssuer = irIssuer;
		IrQuantity = irQuantity;
		IrDate = irDate;
		IrTime = irTime;
	}
	@Override
	public String toString() {
		return "IssueRaw [IrId=" + IrId + ", rId=" + rId + ", IrName=" + IrName + ", IrIssuer=" + IrIssuer
				+ ", IrQuantity=" + IrQuantity + ", IrDate=" + IrDate + ", IrTime=" + IrTime + "]";
	}
	public int getIrId() {
		return IrId;
	}
	public void setIrId(int irId) {
		IrId = irId;
	}
	public int getrId() {
		return rId;
	}
	public void setrId(int rId) {
		this.rId = rId;
	}
	public String getIrName() {
		return IrName;
	}
	public void setIrName(String irName) {
		IrName = irName;
	}
	public String getIrIssuer() {
		return IrIssuer;
	}
	public void setIrIssuer(String irIssuer) {
		IrIssuer = irIssuer;
	}
	public float getIrQuantity() {
		return IrQuantity;
	}
	public void setIrQuantity(float irQuantity) {
		IrQuantity = irQuantity;
	}
	public String getIrDate() {
		return IrDate;
	}
	public void setIrDate(String irDate) {
		IrDate = irDate;
	}
	public String getIrTime() {
		return IrTime;
	}
	public void setIrTime(String irTime) {
		IrTime = irTime;
	}
}
