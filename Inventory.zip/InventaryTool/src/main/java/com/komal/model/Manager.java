package com.komal.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Manager {
	
	@Id
	private String mEmail;
    private String mPassword;	
    
 
	public String getmEmail() {
		return mEmail;
	}
	public void setmEmail(String mEmail) {
		this.mEmail = mEmail;
	}
	public String getmPassword() {
		return mPassword;
	}
	public void setmPassword(String mPassword) {
		this.mPassword = mPassword;
	}
	@Override
	public String toString() {
		return "Manager [mEmail=" + mEmail + ", mPassword=" + mPassword + "]";
	}
	public Manager( String mEmail, String mPassword) {
		super();
	
		this.mEmail = mEmail;
		this.mPassword = mPassword;
	}
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

}