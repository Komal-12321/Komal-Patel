package com.komal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Process {
	
	@Id
	private int pId;
	private String pName;
	private float pQuantity;
	private String pUnit;
	private String pCost;
	public Process() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Process(int pId, String pName, float pQuantity, String pUnit, String pCost) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pQuantity = pQuantity;
		this.pUnit = pUnit;
		this.pCost = pCost;
	}
	@Override
	public String toString() {
		return "Process [pId=" + pId + ", pName=" + pName + ", pQuantity=" + pQuantity + ", pUnit=" + pUnit + ", pCost="
				+ pCost + "]";
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public float getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(float pQuantity) {
		this.pQuantity = pQuantity;
	}
	public String getpUnit() {
		return pUnit;
	}
	public void setpUnit(String pUnit) {
		this.pUnit = pUnit;
	}
	public String getpCost() {
		return pCost;
	}
	public void setpCost(String pCost) {
		this.pCost = pCost;
	}
}