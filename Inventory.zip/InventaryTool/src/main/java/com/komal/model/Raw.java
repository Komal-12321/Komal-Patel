package com.komal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Raw {
	
	@Id
	private int rId;
	private String rName;
	private float rQuantity;
	private String rUnit;
	private String rCost;
	public int getrId() {
		return rId;
	}
	public void setrId(int rId) {
		this.rId = rId;
	}
	public String getrName() {
		return rName;
	}
	public void setrName(String rName) {
		this.rName = rName;
	}
	public float getrQuantity() {
		return rQuantity;
	}
	public void setrQuantity(float rQuantity) {
		this.rQuantity = rQuantity;
	}
	public String getrUnit() {
		return rUnit;
	}
	public void setrUnit(String rUnit) {
		this.rUnit = rUnit;
	}
	public String getrCost() {
		return rCost;
	}
	public void setrCost(String rCost) {
		this.rCost = rCost;
	}
	@Override
	public String toString() {
		return "Raw [rId=" + rId + ", rName=" + rName + ", rQuantity=" + rQuantity + ", rUnit=" + rUnit + ", rCost="
				+ rCost + "]";
	}
	public Raw(int rId, String rName, float rQuantity, String rUnit, String rCost) {
		super();
		this.rId = rId;
		this.rName = rName;
		this.rQuantity = rQuantity;
		this.rUnit = rUnit;
		this.rCost = rCost;
	}
	public Raw() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}